// ignore_for_file: depend_on_referenced_packages, unused_import, prefer_const_constructors_in_immutables, non_constant_identifier_names, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:cyberphish/model/email.dart';
import 'package:get/get.dart';
import 'email Screen/email_screen.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:auto_size_text/auto_size_text.dart';

class MailCard extends StatelessWidget {
  MailCard(
      {Key? key,
      required this.user,
      this.id,
      this.subject,
      this.sender_name,
      this.body,
      this.day,
      this.sender_email,
      this.date,
      this.link})
      : super(key: key);
  final GoogleSignInAccount user;
  final dynamic id;
  final String? subject;
  final String? sender_name;
  final String? body;
  final String? day;
  final String? sender_email;
  final String? date;
  final String? link;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 10.h,
        left: 10.w,
        right: 20.w,
      ),
      child: Container(
        margin: EdgeInsets.only(
          left: 12.w,
        ),
        padding: EdgeInsets.symmetric(
          vertical: 6.h,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(
                top: 5.h,
                right: 5.w,
              ),
            ),
            InkWell(
              onTap: () {
                Get.to(
                    () => EmailScreen(
                        id: id,
                        user: user,
                        subject: subject,
                        sender_name: sender_name,
                        body: body,
                        day: day,
                        date: date,
                        sender_email: sender_email,
                        link: link),
                    duration: Duration(milliseconds: 500),
                    transition: Transition.rightToLeftWithFade);
              },
              borderRadius: BorderRadius.circular(10.r),
              child: Container(
                margin: EdgeInsets.only(
                  bottom: 5.h,
                ),
                padding: EdgeInsets.only(
                  top: 30.h,
                  left: 10.w,
                  right: 20.w,
                  bottom: 30.h,
                ),
                decoration: BoxDecoration(
                  color: Color.fromARGB(57, 241, 233, 233),
                  borderRadius: BorderRadius.circular(20.r),
                  boxShadow: [
                    BoxShadow(
                      color:
                          Color.fromARGB(255, 248, 248, 248).withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: Offset(-1, -1), // changes position of shadow
                    ),
                    BoxShadow(
                      color:
                          Color.fromARGB(255, 248, 248, 248).withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: Offset(1, 1), // changes position of shadow
                    ),
                  ],
                ),
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            sender_name ?? '',
                            style: TextStyle(
                                fontFamily: 'Quicksand-Bold',
                                fontSize: 18.sp,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            day ?? '',
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontFamily: 'Quicksand-light',
                              fontSize: 13.sp,
                              color: Colors.black,
                              //fontWeight: FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: 5.h,
                          bottom: 10.h,
                          left: 7.w,
                        ),
                      ),
                      Text(subject ?? '',
                          style: TextStyle(
                            fontFamily: 'Quicksand-Italic',
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                            color: Colors.deepPurple[400],
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1),
                      Padding(
                        padding:
                            EdgeInsets.only(top: 5.h, bottom: 10.h, left: 7.w),
                      ),
                      Text(
                        body ?? '',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Quicksand-Regular',
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
