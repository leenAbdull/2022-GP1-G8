// ignore_for_file: avoid_print

import 'dart:convert';
import 'package:cyberphish/model/article.dart';
import 'package:cyberphish/model/email.dart';
import 'package:cyberphish/screens/NavBar.dart';
import 'package:cyberphish/screens/home.dart';
import 'package:cyberphish/screens/loading.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'login.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LoginViewModel extends ChangeNotifier {
  //attributes
  final firestore = FirebaseFirestore.instance;
  List<Email> emailsList = [];
  List<article> articleList = [];
  GoogleSignInAccount? currentUser;
  var email_id;

// instance of GoogleSignIn that allows us to use google sign in and sign out
  GoogleSignIn googleSignIn = GoogleSignIn(
    scopes: <String>[
      'email',
      'https://mail.google.com/', // scope that has full access
    ],
  );

  // handle get content method,retrieved from DB
  handleGetContent() async {
    final awareness = FirebaseFirestore.instance.collection('Awareness');
    final articles = await awareness.get();
    for (var articleData in articles.docs) {
      articleList.add(
        // add an article to the list, using the article class
        article(
            title: articleData.data()['title'],
            author: articleData.data()['author'],
            link: articleData.data()['link'],
            content: articleData.data()['content'],
            imgLink: articleData.data()['imgLink']),
      );
    }
    return articleList;
  }

  // handle sign out, empty the email list, return the user to log in screen
  handleSignOut(GoogleSignInAccount currentUser) async {
    await http.post(
      Uri.parse(
          'https://gmail.googleapis.com/gmail/v1/users/${currentUser.id}/stop'),
    );
    firestore
        .collection("GoogleSignInAccount")
        .doc(currentUser.id)
        .set({'userStatus': false});

    emailsList = [];
    await googleSignIn.signOut();

    Get.offAll(() => LoginScreen());
  }

  // sign in method, that handle sign in through Gmail, send the user to handle get email method
  handleSignIn() async {
    try {
      // retrieve user's google account, store user's account in DB in user collection
      currentUser = await googleSignIn.signIn();
      firestore.collection("GoogleSignInAccount").doc(currentUser!.id).set({
        "displayName": currentUser!.displayName,
        'email': currentUser!.email,
        'user_id': currentUser!.id,
        'photoUrl': currentUser!.photoUrl,
        'serverAuthCode': currentUser!.serverAuthCode,
        'userStatus': true
      });
      await handleGetContent();

      Get.to(
        () => NavBar(
          user: currentUser!,
          emailsList: emailsList,
          articleList: articleList,
        ),
      );
    } catch (error) {
      print(error);
    }
  }
}
