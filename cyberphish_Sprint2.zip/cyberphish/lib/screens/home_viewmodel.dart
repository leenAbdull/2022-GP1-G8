// ignore_for_file: use_key_in_widget_constructors, must_be_immutable, curly_braces_in_flow_control_structures, unused_import, depend_on_referenced_packages, prefer_typing_uninitialized_variables, avoid_print, non_constant_identifier_names, camel_case_types, prefer_contains

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cyberphish/model/email.dart';
import 'package:cyberphish/screens/NavBar.dart';
import 'package:cyberphish/screens/login_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:url_launcher/link.dart';
import 'package:url_launcher/url_launcher.dart';
import 'email Screen/email_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'home.dart';
import 'package:html/parser.dart' show parse;

import 'local_Notification_service.dart';

class home_viewmodel {
  final firestore = FirebaseFirestore.instance;
  var emailId;
  var userdata;
  var userStatus;

  void handleGetEmail(GoogleSignInAccount user, emailCheck, emailsList) async {
    print("in handle ");
    var email_messages;
    int count = 0;
    String response_API = '';

    final http.Response getProfile = await http.get(
      // send get request to get the last 100 emails from user inbox
      Uri.parse(
          'https://gmail.googleapis.com/gmail/v1/users/${user.id}/messages/'),
      headers: await user.authHeaders,
    );
    if (getProfile.statusCode != 200) {
      response_API = 'Gmail API  a ${getProfile.statusCode} '
          'response. Check logs for details.';
      Text(response_API);
      return;
    } else {
      // in successful getProfile request state:
      // decode the json response, contain the last 100 email id
      final Map<String, dynamic> allEmailsResponse =
          json.decode(getProfile.body) as Map<String, dynamic>;

      // get the messages of the response, contain  email's id and email's thread for the latest 100 email
      email_messages = allEmailsResponse['messages'];

      // loop on the emails, count how many recieved emails
      for (var email in email_messages) {
        count++;
      }
      print("count $count");
      // loop on to get the emails data
      for (var i = 0; i < count; i++) {
        emailId = allEmailsResponse['messages'][i]['id'].toString();
        emailCheck++;
        extractEmail(user, emailId, emailsList, false);
      }
      print(emailCheck);
      print("done");

      emailStream(user, emailsList);
    }
  }

// trash label and permenant delete
  void emailStream(GoogleSignInAccount user, emailsList) async {
    // send post watch request, to monitor any changes on user Gmail account
    // using this request via sub/pub API and Gmail API
    final http.Response watchRequest = await http.post(
        Uri.parse(
            'https://gmail.googleapis.com/gmail/v1/users/${user.id}/watch'),
        headers: await user.authHeaders,
        body: jsonEncode(<String, String>{
          "topicName": 'projects/cyberphish-gp/topics/cyberphish'
        }));

    // decode the json response, contain the history id
    final Map<String, dynamic> watchResponse =
        json.decode(watchRequest.body) as Map<String, dynamic>;
    print(watchResponse);
    // extract the history id, to use as parameter in the history request query parameter
    var historyId = watchResponse['historyId'];
    int p = 0;
    userdata =
        await firestore.collection("GoogleSignInAccount").doc(user.id).get();
    userStatus = userdata.data()!['userStatus'];
    var old = 0;

    while (userStatus != false) {
      userdata =
          await firestore.collection("GoogleSignInAccount").doc(user.id).get();
      userStatus = userdata.data()!['userStatus'];
      // send get request to get any new changes and updates on the Gmail account
      final http.Response historyRequest = await http.get(
        Uri.parse(
            'https://gmail.googleapis.com/gmail/v1/users/${user.id}/history?startHistoryId=$historyId'),
        headers: await user.authHeaders,
      );
      // decode the json response, contain the new changes
      final Map<String, dynamic> historyResponse =
          json.decode(historyRequest.body) as Map<String, dynamic>;

      //extracting id of new message, then send request to retrieve data, store it
      var ind = 0;

      print('start syncing');
      if (historyResponse['history'] != null) {
        var j = 0;
        try {
          for (var i in historyResponse['history']) {
            if (historyResponse['history'][ind] != null) {
              var length = historyResponse['history'][ind].length;
              if (length > 2 && ind >= old) {
                print('old $old');
                old = old + 1;
                print('new change received');
                if (historyResponse['history'][ind]['key'] == 'messagesAdded')
                  // if there is an added message
                  for (var message in historyResponse['history'][ind]
                      ['messagesAdded'][j]) {
                    j++;
                  }
                if (historyResponse['history'][ind]['messagesAdded'][j]
                        ['message']['id'] !=
                    null) {
                  print('all checked');
                  print(historyResponse['history'][ind]['messagesAdded'][j]
                      ['message']['id']);
                  emailId = historyResponse['history'][ind]['messagesAdded'][j]
                      ['message']['id'];
                  extractEmail(user, emailId, emailsList, true);
                }
              }
              ind++;
            }
          }
        } catch (e) {
          print(e);
        }
      }
      if (historyResponse['key'] == 'historyId') {
        historyId = historyResponse['value'];
      }
    }
    print('end');
  }

  void extractEmail(
      GoogleSignInAccount user, emailId, emailsList, bool flag) async {
    var headers;
    String sender_name = '';
    String sender_email = '';
    String from = '';
    String date = '';
    String day = '';
    String subject = '';
    String body = '';
    String decoded_body = '';
    int startIndex;
    int endIndex;
    String link = '';
    print('in extract');
    print(emailId);
    // send  get request to retrive specific email data using the email id
    final http.Response emailData = await http.get(
      Uri.parse(
          'https://gmail.googleapis.com/gmail/v1/users/${user.id}/messages/${emailId}'),
      headers: await user.authHeaders,
    );
    // decode the response, the response has all single email data, as 7 nested array, 100 fields of data
    final Map<String, dynamic> emailDataResponse =
        json.decode(emailData.body) as Map<String, dynamic>;
    // extract the headers contains all the header info such as sender, date, day, subject using loop through it
    headers = emailDataResponse['payload']['headers'];
    for (var i = 0; i < headers.length; i++) {
      // check if the current header is the From
      if (emailDataResponse['payload']['headers'][i]['name'] == 'From') {
        from = emailDataResponse['payload']['headers'][i]['value'];
        startIndex = from.indexOf("<", 0);
        endIndex = from.indexOf(">", 0);
        // substring the sender name, and sender email
        if (startIndex != -1 && endIndex != -1) {
          sender_email = from.substring(startIndex + 1, endIndex);
          sender_name = from.substring(0, startIndex);
        } else {
          sender_email = from;
          startIndex = from.indexOf("@", 0);
          sender_name = from.substring(0, startIndex);
        }
      }
      // check if the current header is the Date, substring the day from the date
      if (emailDataResponse['payload']['headers'][i]['name'] == 'Date') {
        date = emailDataResponse['payload']['headers'][i]['value'];
        if (date.indexOf("+") != -1) {
          startIndex = date.indexOf("+", 0);
          date = date.substring(0, startIndex);
        } else if (date.indexOf("-") != -1) {
          startIndex = date.indexOf("-", 0);
          date = date.substring(0, startIndex);
        } else if (date.indexOf("G") != -1) {
          startIndex = date.indexOf("G", 0);
          date = date.substring(0, startIndex);
        }
        day = date.substring(0, 3); // substring the day
      }
      // check if the current header is the subject and extract the subject
      if (emailDataResponse['payload']['headers'][i]['name'] == 'Subject') {
        subject = emailDataResponse['payload']['headers'][i]['value'];
      }
    }
    // check if the body has size, it is either in the first path or the second
    if (emailDataResponse['payload']['body']['size'] > 0) {
      body = emailDataResponse['payload']['body']['data'];
    } else if (emailDataResponse['payload']['parts'][0]['body']['data'] !=
        null) {
      body = emailDataResponse['payload']['parts'][0]['body']['data'];
    } else {
      body = ""; // no body found

    }
    if (body.contains("html")) {
      print('html');
      var b = parse(body).outerHtml;

      decoded_body = b;
    }
    // // decode the body from base64 to utf-8
    if (body != "") {
      // fix http links
      decoded_body = utf8.decode(base64.decode(body));
    }

    // add an email to the emailsList, using the email class
    emailsList.add(
      Email(
        email_id: emailId,
        userName: user.displayName,
        userEmail: user.email,
        userImage: user,
        from: from,
        sender_name: sender_name,
        sender_email: sender_email,
        date: date,
        day: day,
        subject: subject,
        body: body,
        decoded_body: decoded_body,
        link: link,
      ),
    );
    print('DB added');
    // add the email to user's collection inside the email's collection
    firestore
        .collection("GoogleSignInAccount")
        .doc(user.id)
        .collection("emailsList")
        .doc(emailId)
        .set({
      'email_id': emailId,
      'from': from,
      'sender_name': sender_name,
      'sender_email': sender_email,
      'date': date,
      'day': day,
      'subject': subject,
      'body': decoded_body,
      'link': link
    });

    if (flag == true) {
      print('emailsList.first.subject ${emailsList.first.subject} ');
      LocalNotificationService().addNotification(
        'New email recieved',
        emailsList.first.subject,
        DateTime.now().millisecondsSinceEpoch + 1000,
        channel: 'testing',
      );
    }
  }
}
