// an article class object has all the retrieved and stored article's data
class article {
  dynamic title;
  String? author;
  String? link;
  String? content;
  String? imgLink;
  article({
    this.title,
    this.author,
    this.link,
    this.content,
    this.imgLink,
  });
}
