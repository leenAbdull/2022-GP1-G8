// ignore_for_file: sort_child_properties_last, prefer_const_constructors

import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cyberphish/model/email.dart';
import 'package:cyberphish/screens/NavBar.dart';
import 'package:cyberphish/screens/login_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'email Screen/email_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'home_viewmodel.dart';
import 'MailCard.dart';
import 'local_Notification_service.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({required this.emailsList, required this.user, Key? key})
      : super(key: key);
  final List<Email> emailsList;
  final GoogleSignInAccount user;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final firestore = FirebaseFirestore.instance;
  var emailId;
  late int emailCheck;
  var userdata;
  var userStatus;
  var flag = true;

  @override
  void initState() {
    super.initState();
    emailCheck = widget.emailsList.length;
  }

  @override
  Widget build(BuildContext context) {
    emailCheck = widget.emailsList.length;
    if (emailCheck == 0) {
      home_viewmodel()
          .handleGetEmail(widget.user, emailCheck, widget.emailsList);
    }
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/images/background2.jpg"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 20.0 * 2.5),
                height: size.height * 0.2,
                child: Stack(
                  children: [
                    Container(
                      padding:
                          EdgeInsets.only(left: 20.0, right: 20.0, bottom: 56),
                      height: size.height * 0.2 - 27,
                      decoration: BoxDecoration(
                        color: Colors.deepPurple,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(36),
                          bottomRight: Radius.circular(36),
                        ),
                      ),
                      child: Row(
                        children: [
                          Text(
                            widget.user.displayName!,
                            style:
                                Theme.of(context).textTheme.headline5?.copyWith(
                                      color: Colors.white,
                                      fontFamily: "Quicksand-LightItalic",
                                      fontWeight: FontWeight.bold,
                                    ),
                          ),
                          Spacer(),
                          CircleAvatar(
                            radius: 20,
                            backgroundColor: Colors.transparent,
                            child: GoogleUserCircleAvatar(
                              identity: widget.user,
                            ),
                          )
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 20.0),
                        height: 54,
                        decoration: BoxDecoration(
                          color: Color(0xECFBFBF9),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              offset: Offset(0, 10),
                              blurRadius: 50,
                              color: Colors.deepPurple.withOpacity(0.23),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            Text(
                              "\"We wish you a safe stay on the internet.\"",
                              style: TextStyle(
                                  fontFamily: "Quicksand-Italic", fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                //const EdgeInsets.only(left: 20.0),
                child: Row(
                  children: [
                    Container(
                      height: 24,
                      child: Stack(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 5),
                            child: Text(
                              "Inbox",
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: "Quicksand-BoldItalic",
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            left: 0,
                            right: 0,
                            child: Container(
                              margin: EdgeInsets.only(right: 5),
                              height: 7,
                              color: Colors.deepPurple.withOpacity(0.2),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 1.sh - 464.h,
                child: StreamBuilder<QuerySnapshot>(
                    stream: firestore
                        .collection("GoogleSignInAccount")
                        .doc(widget.user.id)
                        .collection("emailsList")
                        .snapshots(),
                    builder: (context, snapshot) {
                      List<MailCard> mailcardList = [];
                      if (!snapshot.hasData) {
                        return Center(child: Text('nothing'));
                      }
                      final mails = snapshot.data!.docs.reversed;

                      for (var mail in mails) {
                        final id = mail.get('email_id');
                        final subject = mail.get('subject');
                        final sender_name = mail.get('sender_name');
                        final body = mail.get('body');
                        final day = mail.get('day');
                        final date = mail.get('date');
                        final sender_email = mail.get('sender_email');
                        final prediction = mail.get('prediction');
                        final percentage = mail.get('percentage').toString();
                        // print(id);
                        final List bodyList = mail.get('bodyList');
                        final Map vocabularyList = mail.get('vocabularyList');
                        final mailwidget = MailCard(
                          id: id,
                          user: widget.user,
                          subject: subject,
                          sender_name: sender_name,
                          body: body,
                          day: day,
                          date: date,
                          sender_email: sender_email,
                          prediction: prediction,
                          bodyList: bodyList,
                          vocabularyList: vocabularyList,
                          percentage: percentage,
                        );
                        mailcardList.add(mailwidget);
                      }
                      return Expanded(
                        child: ListView(
                          children: mailcardList,
                          reverse: false,
                        ),
                      );
                    }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
