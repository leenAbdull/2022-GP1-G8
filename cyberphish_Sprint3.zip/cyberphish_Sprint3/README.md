# CyberPhish
## 2022-GP1-G8
CyberPhish is a mobile application that gives users feedback analysis and warns them regarding an email. CyberPhish will be like a safety net that opens users’ eyes to the true purpose of the emails in their inbox.

# Programming Languages:
- Dart/Flutter

# Launching Instructions:
1. Download the APK file on your device.
2. Run the the APK file.
3. Login using the credentials.
4. Allow the CyberPhish app any required Gmail permissions.
5. In case you want to run the code not the APK, run the command: (flutter pub get). Then, run the code

# Login Credentials
Email: Cyberphish.gp2022@gmail.com

Password: CyberPhish2022GP
