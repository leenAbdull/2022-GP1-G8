// ignore_for_file: use_key_in_widget_constructors, must_be_immutable, await_only_futures, curly_braces_in_flow_control_structures, empty_statements

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cyberphish/model/email.dart';
import 'package:cyberphish/screens/NavBar.dart';
import 'package:cyberphish/screens/report_viewmodel.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:html/dom.dart';
import 'package:url_launcher/link.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'home.dart';
import 'package:html/parser.dart' show parse;
import 'local_Notification_service.dart';
import 'package:rational/rational.dart';

// ignore: camel_case_types
class home_viewmodel {
  final firestore = FirebaseFirestore.instance;
  var emailId;
  var userdata;
  var userStatus;

  void handleGetEmail(GoogleSignInAccount user, emailCheck, emailsList) async {
    var emailIDlist;
    int count = 0;
    String responseAPI = '';

    final http.Response getProfile = await http.get(
      // send get request to get the last 100 emails from user inbox
      Uri.parse(
          'https://gmail.googleapis.com/gmail/v1/users/${user.id}/messages/'),
      headers: await user.authHeaders,
    );
    if (getProfile.statusCode != 200) {
      responseAPI = 'Gmail API  a ${getProfile.statusCode} '
          'response. Check logs for details.';
      print(responseAPI);
      return;
    } else {
      //in successful getProfile request state:
      // decode the json response, contain the last 100 email id
      final Map<String, dynamic> allEmailsResponse =
          json.decode(getProfile.body) as Map<String, dynamic>;
      emailIDlist = allEmailsResponse['messages'];

      // loop on the emails, count how many recieved emails, to catch if there is less than 100 email
      for (var email in emailIDlist) {
        count++;
      }
      //loop on to get the emails data, increment the check to prevent redundent request to users' inbox
      for (var i = 0; i < 50; i++) {
        emailId = allEmailsResponse['messages'][i]['id'].toString();
        emailCheck++;
        extractEmail(user, emailId, emailsList, false);
      }
      // send to email stream to monitor for the following recieved emails
      emailStream(user, emailsList, emailCheck);
      //report_viewmodel(user).createReport();
    }
  }

  emailStream(GoogleSignInAccount user, emailsList, emailCheck) async {
    // send post watch request, to monitor any changes on user Gmail account
    // using this request via sub/pub API and Gmail API
    final http.Response watchRequest = await http.post(
        Uri.parse(
            'https://gmail.googleapis.com/gmail/v1/users/${user.id}/watch'),
        headers: await user.authHeaders,
        body: jsonEncode(<String, String>{
          "topicName": 'projects/cyberphish-gp/topics/cyberphish'
        }));

    // decode the json response, contain the history id
    final Map<String, dynamic> watchResponse =
        json.decode(watchRequest.body) as Map<String, dynamic>;
    //extract the history id, to use as parameter in the history request query parameter
    var historyId = watchResponse['historyId'];
    int p = 0;
    userdata =
        await firestore.collection("GoogleSignInAccount").doc(user.id).get();
    userStatus = userdata.data()!['userStatus'];
    var old = 0;

    while (userStatus != false) {
      userdata =
          await firestore.collection("GoogleSignInAccount").doc(user.id).get();
      userStatus = userdata.data()!['userStatus'];
      // send get request to get any new changes and updates on the Gmail account
      final http.Response historyRequest = await http.get(
        Uri.parse(
            'https://gmail.googleapis.com/gmail/v1/users/${user.id}/history?startHistoryId=$historyId'),
        headers: await user.authHeaders,
      );
      // decode the json response, contain the new changes
      final Map<String, dynamic> historyResponse =
          json.decode(historyRequest.body) as Map<String, dynamic>;

      //extracting id of new message, then send request to retrieve data, store it
      var ind = 0;
      if (historyResponse['history'] != null) {
        var j = 0;
        try {
          for (var i in historyResponse['history']) {
            if (historyResponse['history'][ind] != null) {
              var length = historyResponse['history'][ind].length;
              if (length > 2 && ind >= old) {
                old = old + 1;
                if (historyResponse['history'][ind]['key'] == 'messagesAdded')
                  // if there is an added message
                  for (var message in historyResponse['history'][ind]
                      ['messagesAdded'][j]) {
                    j++;
                  }
                if (historyResponse['history'][ind]['messagesAdded'][j]
                        ['message']['id'] !=
                    null) {
                  emailId = historyResponse['history'][ind]['messagesAdded'][j]
                      ['message']['id'];
                  emailCheck++;
                  extractEmail(user, emailId, emailsList, true);
                }
              }
              ind++;
            }
          }
        } catch (e) {
          print(e);
        }
      }
      if (historyResponse['key'] == 'historyId') {
        historyId = historyResponse['value'];
      }
    }
  }

  predict(String subject, String body) async {
    var url = 'https://clownfish-app-9rdvw.ondigitalocean.app';
    //sending a post request to the url
    final http.Response flaskRequest = await http.post(Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{'subject': subject, 'body': body}));

    final Map<String, dynamic> flaskResponse =
        json.decode(flaskRequest.body) as Map<String, dynamic>;

    return flaskResponse;
  }

  // ignore: non_constant_identifier_names
  check_url(url, GoogleSignInAccount user, emailId, linkNum) async {
    var suspicious = false;
    var unsafe = false;
    var phishing = false;
    var riskScore = 0;
    var malware = false;
    url = Uri.encodeComponent(url);
    var key = 'mocbkbu9226A2iXWFLfp2kdVdvV9co22';
    //sending a get request to the url
    // final http.Response linkAPI = await http.get(
    //     Uri.parse('https://www.ipqualityscore.com/api/json/url/$key/$url'),
    //     headers: <String, String>{'strictness': '0'});
    // final Map<String, dynamic> linkAPIResponse =
    //     json.decode(linkAPI.body) as Map<String, dynamic>;
    // var suspicious = linkAPIResponse['suspicious'];
    // var unsafe = linkAPIResponse['unsafe'];
    // var phishing = linkAPIResponse['phishing'];
    // var riskScore = linkAPIResponse['risk_score'];
    // var malware = linkAPIResponse['malware'];

    firestore
        .collection("GoogleSignInAccount")
        .doc(user.id)
        .collection("emailsList")
        .doc(emailId)
        .collection('links')
        .doc('$linkNum')
        .set({
      'Link_string': url,
      'suspicious': suspicious,
      'phishing': phishing,
      'Risk_score': riskScore,
      'malware': malware,
      'unsafe': unsafe,
    });
  }

  // ignore: non_constant_identifier_names
  check_sender(GoogleSignInAccount user, emailId, senderEmail) async {
    var key = 'mocbkbu9226A2iXWFLfp2kdVdvV9co22';
    //sending a get request to the url
    // final http.Response senderAPI = await http.get(
    //   Uri.parse(
    //       'https://www.ipqualityscore.com/api/json/email/$key/$senderEmail'),
    //   // headers: <String, String>{'strictness': '0'}
    // );
    // final Map<String, dynamic> senderAPIResponse =
    //     json.decode(senderAPI.body) as Map<String, dynamic>;
    // var senderFraudScore = senderAPIResponse['fraud_score'];
    // var senderOverallRisk = senderAPIResponse['overall_score'];

    var senderFraudScore = 0;
    var senderOverallRisk = 1;

    //Overall Score
    //| 0 = invalid
    //| 1 = DNS valid, unreachable server
    //| 2 = temporary rejection error
    //| 3 = catch all server
    //| 4 = verified email

    // Fraud Score
    //| 75+ = suspicious
    //| 85+ = risky
    //| 90+ = high risk

    // use Data Leak for the user
    // print('$emailId $senderOverallRisk $senderFraudScore ');
    Map<String, int> RiskMap = {
      "senderFraudScore": senderFraudScore,
      "senderOverallRisk": senderOverallRisk,
    };

    return RiskMap;
  }

  calculatePercentage(
      GoogleSignInAccount user,
      emailId,
      emailWords,
      phishyWords,
      linkNum,
      prediction,
      totalWeightWords,
      senderFraudScore,
      senderOverallRisk) async {
    // 1. seder email risk score
    // 2. num of phishy words/num of words of email -20% - find threshold
    // 3. Sum of the Weight of the phishy words - find threshold
    // 4. Link? Phishy? -40%

    double wordPercentage, percentage = 0;
    int links;

    //Overall Score
    //| 0 = invalid
    //| 1 = DNS valid, unreachable server
    //| 2 = temporary rejection error
    //| 3 = catch all server
    //| 4 = verified email

    // Fraud Score
    //| 75+ = suspicious
    //| 85+ = risky
    //| 90+ = high risk

    wordPercentage = phishyWords + totalWeightWords;
    // print('email result $totalWeightWords $wordPercentage $phishyWords');

    if (senderOverallRisk == 0) {
    } else if (senderOverallRisk == 1) {
    } else if (senderOverallRisk == 2) {
    } else if (senderOverallRisk == 3) {
    } else if (senderOverallRisk == 4) {
      senderOverallRisk = 0;
    }

    var SednerRisk = 0.20 * senderFraudScore;

    if (linkNum >= 1) {
      // no links
      // Link Risk Score
      //| 75+ = suspicious
      //| 85+ = high risk
      //| 90+ = risk
      // use Data Leak for the user
      Query<Map<String, dynamic>> query = firestore
          .collection('GoogleSignInAccount')
          .doc(user.id)
          .collection("emailsList")
          .doc(emailId)
          .collection('links')
          .where('phishing', isEqualTo: true);
      //'Risk_score', isGreaterThan: 30);

      final countQuery = query.count();
      final AggregateQuerySnapshot snapshot = await countQuery.get();
      // print("Count: ${snapshot.count}");
      if (snapshot.count > 0) {
        percentage = wordPercentage + 50 + SednerRisk;
      } else {
        percentage = wordPercentage + SednerRisk;
      }
    }
    String result = percentage.toString();
    try {
      result = result.substring(0, 3);
      percentage = double.parse(result);
    } catch (e) {
      print(e);
      print('error in calculate percentage');
    }

    // print('final result $percentage $wordPercentage  $SednerRisk');
    return percentage;
  }

  extractEmail(GoogleSignInAccount user, emailId, emailsList, bool flag) async {
    var headers;
    String senderName = '';
    String senderEmail = '';
    String from = '';
    String date = '';
    String day = '';
    String subject = '';
    String body = '';
    String parsedBody = '';
    int startIndex;
    int endIndex;
    List bodyList = [];
    String? remainBody = body;
    int linkNum = 0, emailWords = 0, phisyWord = 0;
    RegExp regExp = RegExp(r"[\w-._]+");
    Map<String, double> words = {};
    var percentageResult,
        flaskResponse,
        vocabularyList,
        prediction,
        senderRequest,
        senderOverallRisk,
        senderFraudScore,
        fullDate,
        splittedDate,
        month,
        dayNumber,
        year,
        time,
        week;
    Map<String, dynamic> mapDate = {};

    try {
      // send  get request to retrive specific email data using the email id
      final http.Response emailData = await http.get(
        Uri.parse(
            'https://gmail.googleapis.com/gmail/v1/users/${user.id}/messages/${emailId}'),
        headers: await user.authHeaders,
      );
      //decode the response, the response has all single email data, as 7 nested array, 100 fields of data
      final Map<String, dynamic> emailDataResponse =
          json.decode(emailData.body) as Map<String, dynamic>;
      // extract the headers contains all the header info such as sender, date, day, subject using loop through it
      headers = emailDataResponse['payload']['headers'];
      for (var i = 0; i < headers.length; i++) {
        // check if the current header is the From
        if (emailDataResponse['payload']['headers'][i]['name'] == 'From') {
          from = emailDataResponse['payload']['headers'][i]['value'];
          startIndex = from.indexOf("<", 0);
          endIndex = from.indexOf(">", 0);
          // substring the sender name, and sender email
          if (startIndex != -1 && endIndex != -1) {
            senderEmail = from.substring(startIndex + 1, endIndex);
            senderName = from.substring(0, startIndex);
          } else {
            senderEmail = from;
            startIndex = from.indexOf("@", 0);
            senderName = from.substring(0, startIndex);
          }
        }
        // check if the current header is the Date, substring the day from the date
        if (emailDataResponse['payload']['headers'][i]['name'] == 'Date') {
          date = emailDataResponse['payload']['headers'][i]['value'];
          if (date.indexOf("+") != -1) {
            startIndex = date.indexOf("+", 0);
            date = date.substring(0, startIndex);
          } else if (date.indexOf("-") != -1) {
            startIndex = date.indexOf("-", 0);
            date = date.substring(0, startIndex);
          } else if (date.indexOf("G") != -1) {
            startIndex = date.indexOf("G", 0);
            date = date.substring(0, startIndex);
          }
          day = date.substring(0, 3); // substring the day
          fullDate = date.substring(5);
          splittedDate = fullDate.split(' ').toList();
          month = splittedDate[1];
          dayNumber = int.parse(splittedDate[0]);
          year = int.parse(splittedDate[2]);
          time = splittedDate[3];
          week;
          if (dayNumber <= 7) {
            week = 1;
          } else if (dayNumber > 7 && dayNumber <= 14) {
            week = 2;
          } else if (dayNumber > 14 && dayNumber <= 21) {
            week = 3;
          } else if (dayNumber > 21 && dayNumber <= 31) {
            week = 4;
          }

          if (month == 'Jan') {
            month = 1;
          } else if (month == 'Feb') {
            month = 2;
          } else if (month == 'Mar') {
            month = 3;
          } else if (month == 'Apr') {
            month = 4;
          } else if (month == 'May') {
            month = 5;
          } else if (month == 'Jun') {
            month = 6;
          } else if (month == 'Jul') {
            month = 7;
          } else if (month == 'Aug') {
            month = 8;
          } else if (month == 'Sep') {
            month = 9;
          } else if (month == 'Oct') {
            month = 10;
          } else if (month == 'Nov') {
            month = 11;
          } else if (month == 'Dec') {
            month = 12;
          }

          mapDate = {
            'day': day,
            'dayNumber': dayNumber,
            'month': month,
            'year': year,
            'time': time,
            'week': week,
          };
        }

        // check if the current header is the subject and extract the subject
        if (emailDataResponse['payload']['headers'][i]['name'] == 'Subject') {
          subject = emailDataResponse['payload']['headers'][i]['value'];
        }
      }
      // check if the body has size, it is either in the first path or the second
      if (emailDataResponse['payload']['body']['size'] > 0) {
        body = emailDataResponse['payload']['body']['data'];
      } else if (emailDataResponse['payload']['parts'][0]['body']['data'] !=
          null) {
        body = emailDataResponse['payload']['parts'][0]['body']['data'];
      } else {
        body = ""; // no body found
      }
      if (body.contains('html')) {
        var b = HtmlParser.parseHTML(body).outerHtml;
        body = b;
      }
      // decode the body from base64 to utf-8
      if (body != "") {
        body = utf8.decode(base64.decode(body));
      }
      // print(body);
      remainBody = body;
      body = '';

      while (remainBody!.contains(RegExp("(http|https)?:\/\/")) &&
          remainBody != '') {
        try {
          var startIndex = -1, endIndex = -1;
          String partBod;
          String partBody = '';
          String partLink;

          startIndex = remainBody.indexOf(RegExp("(http|https)?:\/\/"));
          if (remainBody.indexOf(RegExp(r"\s\n\t\v|<|>|\s+| "), startIndex) !=
                  -1 &&
              startIndex != -1) {
            endIndex = remainBody.indexOf(
                RegExp(r"\s|\s+\n\t\v|<|>|\s+| "), startIndex);
            // print('remain $date  $startIndex $endIndex  \n$remainBody  end');
            partBod = remainBody.substring(0, startIndex);
            partLink = remainBody.substring(startIndex, endIndex);
            try {
              var parsedBody = parse(partBod);
              partBody = parse(parsedBody.body!.text).documentElement!.text;
              if (partBody.contains('>') ||
                  partBody.contains('}') ||
                  partBody.contains('{')) {
                // print('new index');

                partBody = partBody.substring(partBody.indexOf('">') + 1);
                partBody = partBody.substring(partBody.indexOf('\/>') + 2);

                partBody = partBody.substring(partBody.lastIndexOf('}') + 1);
              }
              //partBody = partBody.substring(partBody.lastIndexOf('/>') + 1);
              partBody = partBody.replaceAll('<', ' ');
              partBody = partBody.replaceAll('href="', ' ');

              var parsedLink = parse(partLink);
              partLink = parse(parsedLink.body!.text).documentElement!.text;

              // partLink = partLink.substring(partLink.indexOf('https://" '));
              await check_url(partLink, user, emailId, linkNum);
              linkNum++;
            } catch (e) {
              print('inner try $e');
            }
            remainBody = remainBody.substring(endIndex + 1);

            body = body + '\n' + partBody + '\n' + partLink;
            bodyList.add(partBody);
            bodyList.add(partLink);
          } else if (remainBody.indexOf(
                  RegExp(r"\s\n\t\v|<|>|\s+| "), startIndex) ==
              -1) {
            partLink = remainBody.substring(startIndex);
            await check_url(partLink, user, emailId, linkNum);
            linkNum++;
            remainBody = '';
            body = body + '\n' + partLink;
            bodyList.add(partLink);
          }
        } catch (e) {
          print('new while $e');
        }
      }
      if (remainBody != '') {
        // print('lastly');
        var parsedBody = parse(remainBody);
        remainBody = parse(parsedBody.body!.text).documentElement!.text;
        remainBody = remainBody.substring(remainBody.lastIndexOf('>') + 1);
        body = body + '\n' + remainBody;
        bodyList.add(remainBody);
      }
      Iterable matches = regExp.allMatches(body);
      emailWords += matches.length;
      flaskResponse = await predict(subject, body);
      vocabularyList = flaskResponse['vocabulary'];
      double totalWeightWords = 0;

      if (vocabularyList != '{}') {
        var voc = vocabularyList
            .toString()
            .substring(1, vocabularyList.toString().indexOf('}'));

        while (voc != "") {
          try {
            var startIndex, endIndex = -1, midIndex = -1, nextIndex = -1;
            var partKey, partVal;
            startIndex = voc.indexOf("'");
            midIndex = voc.indexOf(":", startIndex);
            endIndex = voc.indexOf('.', startIndex) + 2;
            nextIndex = voc.indexOf(",");

            if (startIndex != -1 && endIndex != -1 && midIndex != -1) {
              partKey = voc.substring(startIndex + 1, midIndex - 1);
              partVal = voc.substring(midIndex + 2, endIndex);
              partVal = double.parse(partVal);
              words[partKey] = partVal;
              totalWeightWords += partVal;
              phisyWord++;

              if (nextIndex != -1) {
                voc = voc.substring(nextIndex + 1);
              } else {
                voc = "";
              }
              // print(voc);
            }
          } catch (e) {
            print(e);
            print('parse voc');
          }
        }
      }
      senderRequest = await check_sender(user, emailId, senderEmail);
      senderOverallRisk = senderRequest['senderOverallRisk'];
      senderFraudScore = senderRequest['senderFraudScore'];
      // print('senderScore $senderFraudScore senderOverallRisk $senderOverallRisk ');

      if (flaskResponse['prediction'] == '0') {
        prediction = 'legitmate';
        percentageResult = await calculatePercentage(
            user,
            emailId,
            emailWords,
            phisyWord,
            linkNum,
            prediction,
            totalWeightWords,
            senderFraudScore,
            senderOverallRisk);
      } else {
        percentageResult = await calculatePercentage(
            user,
            emailId,
            emailWords,
            phisyWord,
            linkNum,
            prediction,
            totalWeightWords,
            senderFraudScore,
            senderOverallRisk);
        if (percentageResult >= 0 && percentageResult < 50) {
          prediction = 'Low';
        } else if (percentageResult >= 50 && percentageResult < 80) {
          prediction = 'Moderate';
        } else if (percentageResult >= 80) {
          prediction = 'High';
        }
      }

      // add an email to the emailsList, using the email class
      emailsList.add(
        // why we dont delete it?
        Email(
            email_id: emailId,
            userName: user.displayName,
            userEmail: user.email,
            userImage: user,
            from: from,
            sender_name: senderName,
            sender_email: senderEmail,
            date: date,
            day: day,
            subject: subject,
            body: body,
            prediction: prediction),
      );

      // add the email to user's collection inside the email's collection
      firestore
          .collection("GoogleSignInAccount")
          .doc(user.id)
          .collection("emailsList")
          .doc(emailId)
          .set({
        'email_id': emailId,
        'from': from,
        'sender_name': senderName,
        'sender_email': senderEmail,
        'date': mapDate,
        'subject': subject,
        'body': body,
        'bodyList': bodyList,
        'prediction': prediction,
        'percentage': percentageResult,
        'senderOverallRisk': senderOverallRisk,
        'senderFraudScore': senderFraudScore,
        'vocabularyList': words,
      });

      // if (DateTime.now().year == year) {
      if (prediction == 'legitmate') {
        // add legitmate
        await firestore
            .collection("GoogleSignInAccount")
            .doc(user.id)
            .collection("report")
            .doc('$year')
            .update({
          '$month.w$week.$dayNumber.legitmate': FieldValue.increment(1),
          '$month.w$week.totalW$week.legitmate': FieldValue.increment(1),
          '$month.totalM$month.legitmate': FieldValue.increment(1),
          'totalY$year.legitmate': FieldValue.increment(1),
          '$month.w$week.$dayNumber.phishing': FieldValue.increment(0),
          '$month.w$week.totalW$week.phishing': FieldValue.increment(0),
          '$month.totalM$month.phishing': FieldValue.increment(0),
          'totalY$year.phishing': FieldValue.increment(0)
        });
        print('added legit $year');
      } else {
        // add phishing
        await firestore
            .collection("GoogleSignInAccount")
            .doc(user.id)
            .collection("report")
            .doc('$year')
            .update({
          '$month.w$week.$dayNumber.phishing': FieldValue.increment(1),
          '$month.w$week.totalW$week.phishing': FieldValue.increment(1),
          '$month.totalM$month.phishing': FieldValue.increment(1),
          'totalY$year.phishing': FieldValue.increment(1),
          '$month.w$week.$dayNumber.legitmate': FieldValue.increment(0),
          '$month.w$week.totalW$week.legitmate': FieldValue.increment(0),
          '$month.totalM$month.legitmate': FieldValue.increment(0),
          'totalY$year.legitmate': FieldValue.increment(0)
        });
      }
      if (flag == true) {
        LocalNotificationService().addNotification(
          'New email recieved',
          subject,
          DateTime.now().millisecondsSinceEpoch + 1000,
          channel: 'testing',
        );
      }
    } catch (e) {
      print(e);
      print('final error');
    }
  }
}


      // } else {
      //   await firestore
      //       .collection("GoogleSignInAccount")
      //       .doc(user.id)
      //       .collection("report")
      //       .doc('$year')
      //       .set({
      //     'totalY$year': {'legitmate': 0, 'phishing': 0},
      //     '$month': {
      //       'totalM$month': {'legitmate': 0, 'phishing': 0},
      //       'w$week': {
      //         '$dayNumber': {'legitmate': 0, 'phishing': 0},
      //         'totalW$week': {'legitmate': 0, 'phishing': 0},
      //       }
      //     },
      //   });
      // }
      // await for (var report in firestore
      //     .collection('GoogleSignInAccount')
      //     .doc(user.id)
      //     .collection("report")
      //     .snapshots()) {
      //   if (report.docs.isNotEmpty) {
      //     // report not empty has at least one year
      //     var length = report.docs.length;
      //     // print('length ${report.docs.length}');
      //     for (var i = 0; i < length; i++) {
      //       //loop on length
      //       // print('Year Not empty ${report.docs[length - 1].id}');
      //       if (report.docs[length - 1].id == '$year') {
      //         // enter the desired year and update it
      //         print(
      //             'year not empty ${report.docs[length - 1].id}  second $year $prediction');
      //         if (prediction == 'legitmate') {
      //           // add legitmate
      //           await firestore
      //               .collection("GoogleSignInAccount")
      //               .doc(user.id)
      //               .collection("report")
      //               .doc('$year')
      //               .update({
      //             '$month.w$week.$dayNumber.legitmate': FieldValue.increment(1),
      //             '$month.w$week.totalW$week.legitmate':
      //                 FieldValue.increment(1),
      //             '$month.totalM$month.legitmate': FieldValue.increment(1),
      //             'totalY$year.legitmate': FieldValue.increment(1)
      //           });
      //           // print('added legit $year');
      //         } else {
      //           // add phishing
      //           await firestore
      //               .collection("GoogleSignInAccount")
      //               .doc(user.id)
      //               .collection("report")
      //               .doc('$year')
      //               .update({
      //             '$month.w$week.$dayNumber.phishing': FieldValue.increment(1),
      //             '$month.w$week.totalW$week.phishing': FieldValue.increment(1),
      //             '$month.totalM$month.phishing': FieldValue.increment(1),
      //             'totalY$year.phishing': FieldValue.increment(1)
      //           });
      //           print('added phishy $year');
      //         }
      //       }
      //     }
      //   } else {
      //     // add the first one
      //     print(' year empty $year');
      //   }
      // }
      //}
      // for (var year in report.docs.toList()) {
      // }