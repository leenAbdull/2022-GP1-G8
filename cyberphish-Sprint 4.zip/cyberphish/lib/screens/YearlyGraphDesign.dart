// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:cyberphish/model/article.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class YearlyGraphDesign extends StatefulWidget {
  YearlyGraphDesign({
    super.key,
    required this.totalphishy,
    required this.totalLegitmate,
    required this.yearlyLegitmateMap,
    required this.yearlyphishingMap,
  });

  final double totalphishy;
  final double totalLegitmate;
  final Map<double, double> yearlyLegitmateMap;
  final Map<double, double> yearlyphishingMap;

  @override
  State<YearlyGraphDesign> createState() => _YearlyGraphDesign();
}

class _YearlyGraphDesign extends State<YearlyGraphDesign> {
  @override
  Widget build(BuildContext context) {
    double maxValue = widget.yearlyLegitmateMap.values.last.toDouble();
    double numMonths = widget.yearlyphishingMap.length.toDouble() - 1;
    print(
        'Enter Graph ${widget.yearlyLegitmateMap} ${widget.yearlyphishingMap}');
    List<FlSpot> phishingspotList = [
      FlSpot(widget.yearlyphishingMap[0]!, widget.yearlyphishingMap[0]!)
    ];
    //  double counter = 0;
    for (var i = 1; i < widget.yearlyphishingMap.length; i++) {
      try {
        // counter++;
        phishingspotList.add(FlSpot(widget.yearlyphishingMap.keys.elementAt(i),
            widget.yearlyphishingMap.values.elementAt(i)));
        if (widget.yearlyphishingMap.values.elementAt(i) > maxValue) {
          maxValue = widget.yearlyphishingMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    List<FlSpot> legitmatespotList = [
      FlSpot(widget.yearlyLegitmateMap[0]!, widget.yearlyLegitmateMap[0]!)
    ];
    // counter = 0;
    for (var i = 1; i < widget.yearlyLegitmateMap.length; i++) {
      try {
        //  counter++;
        legitmatespotList.add(FlSpot(
            widget.yearlyLegitmateMap.keys.elementAt(i),
            widget.yearlyLegitmateMap.values.elementAt(i)));
        if (widget.yearlyLegitmateMap.values.elementAt(i) > maxValue) {
          maxValue = widget.yearlyLegitmateMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    print('List ${legitmatespotList}  \n${phishingspotList}  $numMonths');
    print("max val $maxValue");

    return SingleChildScrollView(
      child: Container(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.2,
              padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  width: MediaQuery.of(context).size.width * 1.2,
                  child: LineChart(
                    LineChartData(
                      borderData: FlBorderData(show: false),
                      minX: 0,
                      maxX: numMonths,
                      minY: 0,
                      maxY: maxValue + 10,
                      backgroundColor: Colors.white,
                      lineBarsData: [
                        LineChartBarData(
                          spots: phishingspotList,
                          isCurved: true,
                          color: Colors.red,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                            show: true,
                            color: Colors.red.withOpacity(0.15),
                          ),
                        ),
                        LineChartBarData(
                          spots: legitmatespotList,
                          isCurved: true,
                          color: Colors.green,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                              show: true,
                              color: Colors.green.withOpacity(0.15)),
                        ),
                      ],
                      gridData: FlGridData(
                        show: true,
                        drawHorizontalLine: true,
                        drawVerticalLine: false,
                        getDrawingVerticalLine: (numMonths) {
                          return FlLine(
                            color: Colors.grey.shade800,
                            strokeWidth: 0.8,
                          );
                        },
                      ),
                      titlesData: FlTitlesData(
                        rightTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                          interval: 1,
                          showTitles: true,
                          reservedSize: 23,
                          getTitlesWidget: (value, meta) {
                            String text = "";
                            if (value == 1) {
                              text = "Jan";
                            }
                            if (value == 2) {
                              text = "Feb";
                            }
                            if (value == 3) {
                              text = "March";
                            }
                            if (value == 4) {
                              text = "Apr";
                            }
                            if (value == 5) {
                              text = "May";
                            }
                            if (value == 6) {
                              text = "Jun";
                            }
                            if (value == 7) {
                              text = "July";
                            }
                            if (value == 8) {
                              text = "Aug";
                            }
                            if (value == 9) {
                              text = "Sep";
                            }
                            if (value == 10) {
                              text = "Oct";
                            }
                            if (value == 11) {
                              text = "Nov";
                            }
                            if (value == 12) {
                              text = "Dec";
                            }
                            return Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                text,
                                style: TextStyle(
                                  color: Color.fromARGB(255, 0, 0, 0),
                                  fontSize: 12,
                                  fontFamily: "Quicksand-BoldItalic",
                                ),
                              ),
                            );
                          },
                        )),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
