// ignore_for_file: use_key_in_widget_constructors, must_be_immutable, await_only_futures, curly_braces_in_flow_control_structures

import 'package:cloud_firestore/cloud_firestore.dart';
// ignore: depend_on_referenced_packages
import 'package:google_sign_in/google_sign_in.dart';

// ignore: camel_case_types
// total phishing email as user choose: yearly/ monthly/ weekly -Done
// num of phishing email as user choose -> square -Done
// most recieved sender sends phishy email based on flag as user choose
// pie chart: most trigger as user choose: yearly/ monthly/ weekly

// This month: W1- W2 -W3 -W4
// This week: 1-2
// This Year: all 2023

// 25 Jan 2023 14:49:32 use flag 2022M1W2
// Map {Year: 2022, Month: Jan , Week : 1}
// extracted the weekly/monthly/yearly total, legitmate, phishing

class report_viewmodel {
  report_viewmodel(this.user);

  final firestore = FirebaseFirestore.instance;
  final GoogleSignInAccount user;
  var flag = 0;

  createReport() async {
    var totalYear = 0;
    var totalPhishy = 0;
    var monthlyPhishing = 0;
    flag++;
    print('create $flag');

    // await for (var messages in firestore
    //     .collection('GoogleSignInAccount')
    //     .doc(user.id)
    //     .collection("emailsList")
    //     .snapshots()) {
    //   for (var message in messages.docs.toList()) {
    //     var prediction = message.data()['prediction'];
    //     var fullDate = message.data()['date'];
    //     var month = fullDate['month']; //month name
    //     var year = fullDate['year'];
    //     var day = fullDate['dayNumber']; // 1.. 31
    //     var week = fullDate['week']; // 1,2,3,4
    //     if (prediction == 'legitmate') {
    //       await firestore
    //           .collection("GoogleSignInAccount")
    //           .doc(user.id)
    //           .collection("report")
    //           .doc('$year')
    //           .update({
    //         '$month.w$week.$day.legitmate': FieldValue.increment(1),
    //         '$month.w$week.totalW$week.legitmate': FieldValue.increment(1),
    //         '$month.totalM$month.legitmate': FieldValue.increment(1),
    //         'totalY$year.legitmate': FieldValue.increment(1)
    //       });
    //     } else {
    //       await firestore
    //           .collection("GoogleSignInAccount")
    //           .doc(user.id)
    //           .collection("report")
    //           .doc('$year')
    //           .update({
    //         '$month.w$week.$day.phishing': FieldValue.increment(1),
    //         '$month.w$week.totalW$week.phishing': FieldValue.increment(1),
    //         '$month.totalM$month.phishing': FieldValue.increment(1),
    //         'totalY$year.phishing': FieldValue.increment(1)
    //       });
    //     }
    //   }
    // }

    await for (var report in firestore
        .collection('GoogleSignInAccount')
        .doc(user.id)
        .collection("report")
        .snapshots()) {
      for (var year in report.docs.toList()) {
        totalYear = year.get('totalY${year.id}')['legitmate'] +
            year.get('totalY${year.id}')['phishing'];
        totalPhishy = year.get('totalY${year.id}')['phishing'];
        print('total Phishy $totalPhishy');
        // print(year.data().toString());

        for (var month in year.data().keys) {
          var totalmonth = 0;
          if (month != 'totalY${year.id}') {
            for (var i = 1; i <= 4; i++) {
              var totalweek = 0;
              try {
                if (year.get(month)['w$i'] != null) {
                  var weeklyValue;
                  if (year.get(month)['w$i']['totalW$i']['legitmate'] != null) {
                    weeklyValue =
                        year.get(month)['w$i']['totalW$i']['legitmate'];
                    print('week $i legitmate $weeklyValue');
                    totalweek = (totalweek + weeklyValue) as int;
                  }
                  if (year.get(month)['w$i']['totalW$i']['phishing'] != null) {
                    weeklyValue =
                        year.get(month)['w$i']['totalW$i']['phishing'];
                    print('week $i phishing $weeklyValue');
                    totalweek = (totalweek + weeklyValue) as int;
                  }
                  print('total week$i  $totalweek');
                }
              } catch (e) {
                print(e);
              }
            }
            var monthlyValue;
            if (year.get(month)['totalM$month']['phishing'] != null) {
              monthlyValue = year.get(month)['totalM$month']['phishing'];
              print('month $month phishing $monthlyValue ');
              totalmonth = (totalmonth + monthlyValue) as int;
            }
            if (year.get(month)['totalM$month']['legitmate'] != null) {
              monthlyValue = year.get(month)['totalM$month']['legitmate'];
              print('month $month legitmate $monthlyValue ');
              totalmonth = (totalmonth + monthlyValue) as int;
            }
            print('total month $totalmonth');
          }
        }
        print(
            'total year ${year.id} $totalYear ${year.get('totalY${year.id}')['legitmate']} ${year.get('totalY${year.id}')['phishing']}');
      }
    }
    return totalYear;
  }
}

    // Map<dynamic, dynamic> counterMap = {
    //   2023: {
    //     1: {
    //       // Month
    //       'w1': {
    //         // Week
    //         1: {'legitmate': 0, 'phishing': 0}, //Days
    //         2: {'legitmate': 0, 'phishing': 0},
    //         3: {'legitmate': 0, 'phishing': 0},
    //         4: {'legitmate': 0, 'phishing': 0},
    //         5: {'legitmate': 0, 'phishing': 0},
    //         6: {'legitmate': 0, 'phishing': 0},
    //         7: {'legitmate': 0, 'phishing': 0},
    //         'totalW': {'legitmate': 0, 'phishing': 0},
    //       },
    //       'w2': {
    //         1: {'legitmate': 0, 'phishing': 0},
    //         2: {'legitmate': 0, 'phishing': 0},
    //         3: {'legitmate': 0, 'phishing': 0},
    //         4: {'legitmate': 0, 'phishing': 0},
    //         5: {'legitmate': 0, 'phishing': 0},
    //         6: {'legitmate': 0, 'phishing': 0},
    //         7: {'legitmate': 0, 'phishing': 0},
    //         'total': {'legitmate': 0, 'phishing': 0},
    //       },
    //       'totalM': {'legitmate': 0, 'phishing': 0},
    //     },
    //     'totalY': {'legitmate': 0, 'phishing': 0},
    //   }
    // };
  // await for (var messages in firestore
    //     .collection('GoogleSignInAccount')
    //     .doc(user.id)
    //     .collection("emailsList")
    //     .snapshots()) {
    //   for (var message in messages.docs.toList()) {
    //     //print(message.data()['date']);
    //     var prediction = message.data()['prediction'];
    //     var fullDate = message.data()['date'];
    //     var month = fullDate['month']; //month name
    //     var year = fullDate['year'];
    //     var day = fullDate['dayNumber']; // 1.. 31
    //     var week = fullDate['week']; // 1,2,3,4
    //     // if (prediction == 'legitmate') {
    //     //   // add totalM & totalW increment
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update(
    //     //           {'$month.w$week.$day.legitmate': FieldValue.increment(1)});
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update(
    //     //           {'$month.w$week.totalW.legitmate': FieldValue.increment(1)});
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update({'$month.totalM.legitmate': FieldValue.increment(1)});
    //     // } else {
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update({'$month.w$week.$day.phishing': FieldValue.increment(1)});
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update(
    //     //           {'$month.w$week.totalW.phishing': FieldValue.increment(1)});
    //     //   firestore
    //     //       .collection("GoogleSignInAccount")
    //     //       .doc(user.id)
    //     //       .collection("report")
    //     //       .doc('$year')
    //     //       .update({'$month.totalM.phishing': FieldValue.increment(1)});
    //     // }
    //     print('done $year $month $week $day');
        // for (var i = 1; i <= monthNumber; i++) {
        //   for (var i = 1; i <= week; i++) {
        //     for (var i = 1; i <= day; i++) {}
        //   }
        // }
        // switch (monthNumber) {
        //   case 'Jan':
        //     {
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Feb':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Mar':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Apr':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'May':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Jun':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Jul':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Aug':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Sep':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Oct':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Nov':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        //   case 'Dec':
        //     {
        //       dateFlag = dateFlag + 'M2';
        //       if (prediction == 'legitmate') {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({'$month.legitmate': FieldValue.increment(1)});
        //       } else {
        //         firestore
        //             .collection("GoogleSignInAccount")
        //             .doc(user.id)
        //             .collection("report")
        //             .doc('ThisYear')
        //             .update({
        //           '$month.phishing': FieldValue.increment(1),
        //         });
        //       }
        //       break;
        //     }
        // }
        // if (d <= 7) dateFlag = dateFlag + 'W1';
        // if (d > 7 && d <= 14) dateFlag = dateFlag + 'W2';
        // if (d > 14 && d <= 21) dateFlag = dateFlag + 'W3';
        // if (d > 21 && d <= 31) dateFlag = dateFlag + 'W4';