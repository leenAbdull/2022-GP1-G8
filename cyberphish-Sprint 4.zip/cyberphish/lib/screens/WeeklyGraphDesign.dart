// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:cyberphish/model/article.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class WeeklyGraphDesign extends StatefulWidget {
  WeeklyGraphDesign({
    super.key,
    required this.totalphishy,
    required this.totalLegitmate,
    required this.weeklyLegitmateMap,
    required this.weeklyphishingMap,
  });

  final double totalphishy;
  final double totalLegitmate;
  final Map<double, double> weeklyLegitmateMap;
  final Map<double, double> weeklyphishingMap;

  @override
  State<WeeklyGraphDesign> createState() => _WeeklyGraphDesign();
}

class _WeeklyGraphDesign extends State<WeeklyGraphDesign> {
  @override
  Widget build(BuildContext context) {
    widget.weeklyLegitmateMap.remove(widget.weeklyLegitmateMap.values.first);
    widget.weeklyphishingMap.remove(widget.weeklyphishingMap.values.first);

    double maxValue = widget.weeklyLegitmateMap.values.last.toDouble();
    double numDays = widget.weeklyphishingMap.length.toDouble() - 1;
    print(
        'Enter Graph ${widget.weeklyLegitmateMap} ${widget.weeklyphishingMap}');
    List<FlSpot> phishingspotList = [
      FlSpot(widget.weeklyphishingMap.keys.elementAt(0),
          widget.weeklyphishingMap.values.elementAt(0))
    ];
    //  double counter = 0;
    for (var i = 1; i < widget.weeklyphishingMap.length; i++) {
      try {
        // counter++;
        phishingspotList.add(FlSpot(widget.weeklyphishingMap.keys.elementAt(i),
            widget.weeklyphishingMap.values.elementAt(i)));
        if (widget.weeklyphishingMap.values.elementAt(i) > maxValue) {
          maxValue = widget.weeklyphishingMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    List<FlSpot> legitmatespotList = [
      FlSpot(widget.weeklyLegitmateMap.keys.elementAt(0),
          widget.weeklyLegitmateMap.values.elementAt(0))
    ];
    for (var i = 1; i < widget.weeklyLegitmateMap.length; i++) {
      try {
        legitmatespotList.add(FlSpot(
            widget.weeklyLegitmateMap.keys.elementAt(i),
            widget.weeklyLegitmateMap.values.elementAt(i)));
        if (widget.weeklyLegitmateMap.values.elementAt(i) > maxValue) {
          maxValue = widget.weeklyLegitmateMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    print('List ${legitmatespotList}  \n${phishingspotList}  $numDays');
    print("max val $maxValue");
    print(widget.weeklyLegitmateMap.keys.first);

    return SingleChildScrollView(
      child: Container(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.2,
              padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  width: MediaQuery.of(context).size.width * 1.2,
                  child: LineChart(
                    LineChartData(
                      borderData: FlBorderData(show: false),
                      minX: widget.weeklyLegitmateMap.keys.first,
                      maxX: widget.weeklyLegitmateMap.keys.last,
                      minY: 0,
                      maxY: maxValue + 10,
                      backgroundColor: Colors.white,
                      lineBarsData: [
                        LineChartBarData(
                          spots: phishingspotList,
                          isCurved: true,
                          color: Colors.red,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                            show: true,
                            color: Colors.red.withOpacity(0.15),
                          ),
                        ),
                        LineChartBarData(
                          spots: legitmatespotList,
                          isCurved: true,
                          color: Colors.green,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                              show: true,
                              color: Colors.green.withOpacity(0.15)),
                        ),
                      ],
                      gridData: FlGridData(
                        show: true,
                        drawHorizontalLine: true,
                        drawVerticalLine: false,
                        getDrawingVerticalLine: (numMonths) {
                          return FlLine(
                            color: Colors.grey.shade800,
                            strokeWidth: 0.8,
                          );
                        },
                      ),
                      titlesData: FlTitlesData(
                        rightTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        // topTitles: AxisTitles(
                        //     sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                          interval: 1,
                          showTitles: true,
                          reservedSize: 23,
                          getTitlesWidget: (value, meta) {
                            String text = "";
                            try {
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(0)) {
                                text = "Sun";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(1)) {
                                text = "Mon";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(2)) {
                                text = "Tue";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(3)) {
                                text = "Wed";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(4)) {
                                text = "Thur";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(5)) {
                                text = "Fri";
                              }
                              if (value ==
                                  widget.weeklyLegitmateMap.keys.elementAt(6)) {
                                text = "Sat";
                              }
                            } catch (e) {
                              print(e);
                            }

                            return Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                text,
                                style: TextStyle(
                                  color: Color.fromARGB(255, 0, 0, 0),
                                  fontSize: 12,
                                  fontFamily: "Quicksand-BoldItalic",
                                ),
                              ),
                            );
                          },
                        )),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
