// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:cyberphish/model/article.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class MonthlyGraphDesign extends StatefulWidget {
  MonthlyGraphDesign({
    super.key,
    required this.totalphishy,
    required this.totalLegitmate,
    required this.monthlyLegitmateMap,
    required this.monthlyphishingMap,
  });

  final double totalphishy;
  final double totalLegitmate;
  final Map<double, double> monthlyLegitmateMap;
  final Map<double, double> monthlyphishingMap;

  @override
  State<MonthlyGraphDesign> createState() => _MonthlyGraphDesign();
}

class _MonthlyGraphDesign extends State<MonthlyGraphDesign> {
  @override
  Widget build(BuildContext context) {
    double maxValue = widget.monthlyLegitmateMap.values.last.toDouble();
    double numWeeks = widget.monthlyphishingMap.length.toDouble() - 1;
    print(
        'Enter Graph ${widget.monthlyLegitmateMap} ${widget.monthlyphishingMap}');
    List<FlSpot> phishingspotList = [
      FlSpot(widget.monthlyphishingMap[0]!, widget.monthlyphishingMap[0]!)
    ];
    //  double counter = 0;
    for (var i = 1; i < widget.monthlyphishingMap.length; i++) {
      try {
        // counter++;
        phishingspotList.add(FlSpot(widget.monthlyphishingMap.keys.elementAt(i),
            widget.monthlyphishingMap.values.elementAt(i)));
        if (widget.monthlyphishingMap.values.elementAt(i) > maxValue) {
          maxValue = widget.monthlyphishingMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    List<FlSpot> legitmatespotList = [
      FlSpot(widget.monthlyLegitmateMap[0]!, widget.monthlyLegitmateMap[0]!)
    ];
    // counter = 0;
    for (var i = 1; i < widget.monthlyLegitmateMap.length; i++) {
      try {
        //  counter++;
        legitmatespotList.add(FlSpot(
            widget.monthlyLegitmateMap.keys.elementAt(i),
            widget.monthlyLegitmateMap.values.elementAt(i)));
        if (widget.monthlyLegitmateMap.values.elementAt(i) > maxValue) {
          maxValue = widget.monthlyLegitmateMap.values.elementAt(i);
        }
      } catch (e) {
        //print(e);
      }
    }
    print('List ${legitmatespotList}  \n${phishingspotList}  $numWeeks');
    print("max val $maxValue");

    return SingleChildScrollView(
      child: Container(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.2,
              padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  width: MediaQuery.of(context).size.width * 1.2,
                  child: LineChart(
                    LineChartData(
                      borderData: FlBorderData(show: false),
                      minX: 0,
                      maxX: numWeeks,
                      minY: 0,
                      maxY: maxValue,
                      backgroundColor: Colors.white,
                      lineBarsData: [
                        LineChartBarData(
                          spots: phishingspotList,
                          isCurved: true,
                          color: Colors.red,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                            show: true,
                            color: Colors.red.withOpacity(0.15),
                          ),
                        ),
                        LineChartBarData(
                          spots: legitmatespotList,
                          isCurved: true,
                          color: Colors.green,
                          barWidth: 2,
                          belowBarData: BarAreaData(
                              show: true,
                              color: Colors.green.withOpacity(0.15)),
                        ),
                      ],
                      gridData: FlGridData(
                        show: true,
                        drawHorizontalLine: true,
                        drawVerticalLine: false,
                        getDrawingVerticalLine: (numMonths) {
                          return FlLine(
                            color: Colors.grey.shade800,
                            strokeWidth: 0.8,
                          );
                        },
                      ),
                      titlesData: FlTitlesData(
                        rightTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                          interval: 1,
                          showTitles: true,
                          reservedSize: 23,
                          getTitlesWidget: (value, meta) {
                            String text = "";
                            if (value == 1) {
                              text = "Week 1";
                            }
                            if (value == 2) {
                              text = "Week 2";
                            }
                            if (value == 3) {
                              text = "Week 3";
                            }
                            if (value == 4) {
                              text = "Week 4";
                            }
                            return Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                text,
                                style: TextStyle(
                                  color: Color.fromARGB(255, 0, 0, 0),
                                  fontSize: 12,
                                  fontFamily: "Quicksand-BoldItalic",
                                ),
                              ),
                            );
                          },
                        )),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
