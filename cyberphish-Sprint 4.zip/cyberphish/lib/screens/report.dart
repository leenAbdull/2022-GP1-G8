// ignore_for_file: unused_element, prefer_const_constructors, sort_child_properties_last,
// ignore: depend_on_referenced_packages
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'WeeklyGraphDesign.dart';
import 'YearlyGraphDesign.dart';
import 'MonthlyGraphDesign.dart';
import 'package:cyberphish/model/email.dart';
import 'package:cyberphish/screens/report_viewmodel.dart';
import 'package:d_chart/d_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
// ignore: depend_on_referenced_packages
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:fl_chart/fl_chart.dart';

class ReportScreen extends StatefulWidget {
  ReportScreen({
    Key? key,
    required this.user,
  }) : super(key: key);
  final GoogleSignInAccount user;
  final firestore = FirebaseFirestore.instance;
  @override
  State<ReportScreen> createState() => _reportScreenState();
}

// ignore: camel_case_types
class _reportScreenState extends State<ReportScreen> {
  final firestore = FirebaseFirestore.instance;
  final _scrollController = ScrollController();
  String weekNum() {
    var weeknum;
    var day = DateTime.now().day;
    var month = monthName().substring(0, 3);

    if (day <= 7) weeknum = '1 $month to 7 $month';
    if (day > 7 && day <= 14) weeknum = '8 $month to 14 $month';
    if (day > 14 && day <= 21) weeknum = '15 $month to 21 $month';
    if (day > 21 && day <= 31) {
      weeknum = '22  $month to 31 $month';
    } // specify based on months
    return weeknum;
  }

  String monthName() {
    var monthName;
    var month = DateTime.now().month;
    if (month == 1) {
      monthName = "January";
    } else if (month == 2) {
      monthName = "February";
    } else if (month == 3) {
      monthName = "March";
    } else if (month == 4) {
      monthName = "April";
    } else if (month == 5) {
      monthName = "May";
    } else if (month == 6) {
      monthName = "June";
    } else if (month == 7) {
      monthName = "July";
    } else if (month == 8) {
      monthName = "August";
    } else if (month == 9) {
      monthName = "Septemper";
    } else if (month == 10) {
      monthName = "October";
    } else if (month == 11) {
      monthName = "November";
    } else if (month == 12) {
      monthName = "December";
    }
    return monthName;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double totalPhishy = 0;
    double totalLegitmate = 0;
    Map<dynamic, dynamic>? map;
    Map<double, double> yearlyLegitmateMap = {0: 0};
    Map<double, double> yearlyphishingMap = {0: 0};
    Map<double, double> monthlyLegitmateMap = {0: 0};
    Map<double, double> monthlyphishingMap = {0: 0};
    Map<double, double> weeklyLegitmateMap = {0: 0};
    Map<double, double> weeklyphishingMap = {0: 0};
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 20.0 * 2.5),
            height: size.height * 0.2,
            child: Stack(
              children: [
                Container(
                  padding: EdgeInsets.only(
                    left: 20.0,
                    right: 20.0,
                    bottom: 56.0,
                  ),
                  height: size.height * 0.2 - 27,
                  decoration: BoxDecoration(
                    color: Colors.deepPurple,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(36),
                      bottomRight: Radius.circular(36),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Report",
                        style: Theme.of(context).textTheme.headline5?.copyWith(
                              color: Colors.white,
                              fontFamily: "Quicksand-LightItalic",
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 20.0),
                    height: 54,
                    decoration: BoxDecoration(
                      color: Color(0xECFBFBF9),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          offset: Offset(0, 10),
                          blurRadius: 50,
                          color: Colors.deepPurple.withOpacity(0.23),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text(
                          "\"We wish you a safe stay on the internet.\"",
                          style: TextStyle(
                              fontFamily: "Quicksand-Italic", fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 9, left: 20, top: 9, bottom: 9),
            child: StreamBuilder<QuerySnapshot>(
                stream: firestore
                    .collection("GoogleSignInAccount")
                    .doc(widget.user.id)
                    .collection("report")
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: Text('No Reports yet!'));
                  }
                  final reports = snapshot.data!.docs.toList();
                  int yearlyPhishing = 0;
                  int yearlyLegitmate = 0;
                  for (var year in reports) {
                    yearlyPhishing = year.get('totalY${year.id}')['phishing'];
                    yearlyLegitmate = year.get('totalY${year.id}')['legitmate'];
                    totalPhishy = yearlyPhishing.toDouble();
                    totalLegitmate = yearlyLegitmate.toDouble();

                    map = year.data() as Map?;
                    int monthlyPhishing = 0;
                    int monthlyLegitmate = 0;
                    double monthId;

                    for (var month in map!.keys) {
                      if (month != 'totalY${year.id}' &&
                          year.id == '${DateTime.now().year}') {
                        monthId = double.parse(month);
                        if (year.get(month)['totalM$month']['phishing'] !=
                            null) {
                          monthlyPhishing =
                              year.get(month)['totalM$month']['phishing'];
                          yearlyphishingMap[monthId] =
                              monthlyPhishing.toDouble();
                        }
                        if (year.get(month)['totalM$month']['legitmate'] !=
                            null) {
                          monthlyLegitmate =
                              year.get(month)['totalM$month']['legitmate'];

                          yearlyLegitmateMap[monthId] =
                              monthlyLegitmate.toDouble();
                        }

                        var weeknum = 0;
                        var today = DateTime.now().day;
                        var dayStart = 0;
                        if (today <= 7) {
                          weeknum = 1;
                          dayStart = 1;
                        }

                        if (today > 7 && today <= 14) {
                          weeknum = 2;
                          dayStart = 8;
                        }
                        if (today > 14 && today <= 21) {
                          weeknum = 3;
                          dayStart = 15;
                        }
                        if (today > 21 && today <= 31) {
                          weeknum = 4;
                          dayStart = 22;
                        }
                        for (int week = 1; week <= weeknum; week++) {
                          // starting from first week to the current week
                          int weeklyPhishing = 0;
                          int weeklyLegitmate = 0;
                          double weekId = week.toDouble();
                          try {
                            if (year.get(month)['w$week'] != null &&
                                month == '${DateTime.now().month}') {
                              // make sure not null and in the current month
                              if (year.get(month)['w$week']['totalW$week']
                                      ['legitmate'] !=
                                  null) {
                                weeklyLegitmate = year.get(month)['w$week']
                                    ['totalW$week']['legitmate'];
                                monthlyLegitmateMap[weekId] =
                                    weeklyLegitmate.toDouble();
                              }
                              if (year.get(month)['w$week']['totalW$week']
                                      ['phishing'] !=
                                  null) {
                                weeklyPhishing = year.get(month)['w$week']
                                    ['totalW$week']['phishing'];
                                monthlyphishingMap[weekId] =
                                    weeklyPhishing.toDouble();
                              }
                            }
                          } catch (e) {
                            print(e);
                          }
                          for (dayStart; dayStart <= today; dayStart++) {
                            //start from first day of the week to the current day
                            int dailyPhishing = 0;
                            int dailyLegitmate = 0;
                            double dayId = dayStart.toDouble();
                            try {
                              if (year.get(month)['w$weeknum'] != null &&
                                  month == '${DateTime.now().month}') {
                                if (year.get(month)['w$weeknum']['$dayStart'] !=
                                    null) {
                                  dailyLegitmate = year.get(month)['w$weeknum']
                                      ['$dayStart']['legitmate'];
                                  weeklyLegitmateMap[dayId] =
                                      dailyLegitmate.toDouble();
                                } else {
                                  weeklyLegitmateMap[dayId] = 0;
                                }
                                if (year.get(month)['w$weeknum']['$dayStart'] !=
                                    null) {
                                  dailyPhishing = year.get(month)['w$weeknum']
                                      ['$dayStart']['phishing'];
                                  weeklyphishingMap[dayId] =
                                      dailyPhishing.toDouble();
                                } else {
                                  weeklyphishingMap[dayId] = 0;
                                }
                              }
                            } catch (e) {
                              print(e);
                            }
                          }
                        }
                      }
                    }
                  }

                  // var userChoice = "This year"; // works good
                  // var userChoice = "This month"; // works good
                  var userChoice = "This week";

                  if (userChoice == "This year") {
                    return Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 24,
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 5),
                                    child: Text(
                                      "${DateTime.now().year} Analytics",
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontFamily: "Quicksand-BoldItalic",
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    child: Container(
                                      margin: EdgeInsets.only(right: 5),
                                      height: 7,
                                      color: Colors.deepPurple.withOpacity(0.2),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Scrollbar(
                          controller:
                              _scrollController, // <---- Here, the controller
                          isAlwaysShown: true,
                          thickness: 8,
                          radius:
                              Radius.circular(20), //corner radius of scrollbar
                          scrollbarOrientation: ScrollbarOrientation.bottom,
                          child: SingleChildScrollView(
                            controller: _scrollController,
                            scrollDirection: Axis.horizontal,
                            child: Padding(
                              padding: EdgeInsets.only(
                                top: 3,
                                left: 3,
                                right: 3,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                // ignore: prefer_const_literals_to_create_immutables
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: 5,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(
                                      bottom: 5,
                                    ),
                                    padding: EdgeInsets.only(
                                      top: 30,
                                      right: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 255, 255, 255),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    child: YearlyGraphDesign(
                                      totalphishy: totalPhishy,
                                      totalLegitmate: totalLegitmate,
                                      yearlyLegitmateMap: yearlyLegitmateMap,
                                      yearlyphishingMap: yearlyphishingMap,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  } else if (userChoice == "This month") {
                    return Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 24,
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 5),
                                    child: Text(
                                      "${monthName()} Analytics",
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontFamily: "Quicksand-BoldItalic",
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    child: Container(
                                      margin: EdgeInsets.only(right: 5),
                                      height: 7,
                                      color: Colors.deepPurple.withOpacity(0.2),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Scrollbar(
                          controller:
                              _scrollController, // <---- Here, the controller
                          isAlwaysShown: true,
                          thickness: 8,
                          radius:
                              Radius.circular(20), //corner radius of scrollbar
                          scrollbarOrientation: ScrollbarOrientation.bottom,
                          child: SingleChildScrollView(
                            controller: _scrollController,
                            scrollDirection: Axis.horizontal,
                            child: Padding(
                              padding: EdgeInsets.only(
                                top: 3,
                                left: 3,
                                right: 3,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                // ignore: prefer_const_literals_to_create_immutables
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: 5,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(
                                      bottom: 5,
                                    ),
                                    padding: EdgeInsets.only(
                                      top: 30,
                                      right: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 255, 255, 255),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    child: MonthlyGraphDesign(
                                      totalphishy: totalPhishy,
                                      totalLegitmate: totalLegitmate,
                                      monthlyphishingMap: monthlyphishingMap,
                                      monthlyLegitmateMap: monthlyLegitmateMap,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  } else {
                    return Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 24,
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 5),
                                    child: Text(
                                      "From ${weekNum()} Analytics",
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontFamily: "Quicksand-BoldItalic",
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    child: Container(
                                      margin: EdgeInsets.only(right: 5),
                                      height: 7,
                                      color: Colors.deepPurple.withOpacity(0.2),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Scrollbar(
                          controller:
                              _scrollController, // <---- Here, the controller
                          isAlwaysShown: true,
                          thickness: 8,
                          radius:
                              Radius.circular(20), //corner radius of scrollbar
                          scrollbarOrientation: ScrollbarOrientation.bottom,
                          child: SingleChildScrollView(
                            controller: _scrollController,
                            scrollDirection: Axis.horizontal,
                            child: Padding(
                              padding: EdgeInsets.only(
                                top: 3,
                                left: 3,
                                right: 3,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                // ignore: prefer_const_literals_to_create_immutables
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: 5,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(
                                      bottom: 5,
                                    ),
                                    padding: EdgeInsets.only(
                                      top: 30,
                                      right: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 255, 255, 255),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                        BoxShadow(
                                          color:
                                              Color.fromARGB(255, 196, 196, 196)
                                                  .withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurRadius: 5,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    child: WeeklyGraphDesign(
                                      totalphishy: totalPhishy,
                                      totalLegitmate: totalLegitmate,
                                      weeklyphishingMap: weeklyphishingMap,
                                      weeklyLegitmateMap: weeklyLegitmateMap,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  }
                }),
          )
        ],
      ),
    );
  }
}

// for Chart data use column chart
// firestore number of legitmate emails & num of phishing in a duration
