from flask import Flask, request, jsonify, json

app = Flask(__name__)


@app.route('/api', methods=['GET', 'POST'])
def returnascii():

    if (request.method == 'POST'):
        subject = ''
        body = ''
        data = request.data
        request_data = json.loads(data.decode('utf-8'))

        subject = request_data['subject']
        body = request_data['body']

        response = f'Post\n {subject} \n {body} '

        return jsonify({'output': response})


if __name__ == "__main__":
    app.run()

'''
import json
from os import pipe
import string
from flask import Flask, request, jsonify
import numpy as np
import pickle
from sklearn import preprocessing
import socketio
model = pickle.load(open('nb.pkl', 'rb'))
app = Flask(__name__)

# declared an empty variable for reassignment
response = ''


@app.route('/o', methods=['GET', 'POST'])
def pred():
    global response
    # checking the request type we get from the app
    if (request.method == 'GET'):
        print('inn')
       request_data = request.data  # getting the response data
        request_data = json.loads(request_data.decode('utf-8'))
        # converting it from json to key value pair
        # body = ''
        # subject = ''
        # subject = str(request.args['subject'])
        # body = str(request.args['body'])

        # re-assigning response with the name we got from the user
        subject = 'our mentor'
        body = "Respected Sir, \n It is one thing for you to be a boss, but being a mentor and a leader was never a requirement. \nWe are so proud and grateful to have a boss, manager and mentor in one.\n Thank you for everything that you do Thank you \n Regards"

        def remove_punctuation(text):
            punctuationfree = "".join(
                [i for i in text if i not in string.punctuation])
            return punctuationfree

        body = (lambda body: remove_punctuation(body))

        le = preprocessing.LabelEncoder()
        SUBJECT_encoded = le.fit_transform(subject)
        BODY_encoded = le.fit_transform(body)

        tp = np.array(SUBJECT_encoded)
        fp = np.array(BODY_encoded)

        features = np.vstack((tp, fp)).T
        input_cols = [[features]]
        prediction = model.predict(input_cols)

        response = f'Hi! this Post {subject} {body} {prediction} is Python'
        return jsonify({'pred': response})  # to avoid a type error
    else:
        # sending data back to your frontend app
        response = f'Hi ! this is Get Python'
        return jsonify({'pred': response})


if __name__ == "__main__":
    app.run(debug=True)


'''
